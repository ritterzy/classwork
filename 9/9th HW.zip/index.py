# инициализация переменной
# while условие:
        # тело цикла
# !В цикле While условие когда то должно стать False
# ? В уссловии есть переменнная . которая должна меняться при каждом проходе цикла
# * Переменная меняеться в цикле
# # ! Обыччно переменная являеться счётчиком


сссс



# for i in range (200,149,-10):
#         print(i)

# i = 200
# while i >= 150:
#         print(i)
#         i = i - 10


# name = "ABDUVALI"
# i = 0
# while  i < 8:
        #! print( name[i]) -> ! len(name)
#         i = i + 1


# for ltr in name:
#         print(ltr,end = "/")


# while 1>0:
#         pass

# i = 0
# while True:
#         print("ELBEK")
#         i=i+ 1
#         if i ==10:
#                 break



# while True:
#         num =int(input("ENTER NUMBER:"))
#         if num <0:
#                 break





students =['umar','abduvali','oybek','loh']
age = [16,16,13,15,15]
countries =["Uzbekistan","USA","Germany","Poland","Sweden"]
country_codes=["uz","PO",'UK', "UA"]
